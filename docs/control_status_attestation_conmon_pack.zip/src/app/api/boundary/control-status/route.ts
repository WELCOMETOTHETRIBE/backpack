import { NextResponse } from "next/server";
import { requireOrg } from "@/lib/auth/requireOrg";
import { db } from "@/db";
import { accountBoundary, boundarySnapshots, evidenceRuns, evidenceFindings } from "@/db/schema";
import { desc, eq, inArray } from "drizzle-orm";
import fs from "fs";
import path from "path";
import { synthesizeControlStatus, type AllocationSummary, type EvidenceFindingSummary } from "@/lib/evidence/controlStatus";

function loadControlsRegistry(): { control_id: string; layer?: string | null }[] {
  const registryPath = path.join(process.cwd(), "src", "boundary-engine", "data", "controls", "controls_registry.json");
  if (!fs.existsSync(registryPath)) return [];
  const raw = JSON.parse(fs.readFileSync(registryPath, "utf-8"));
  const arr = Array.isArray(raw) ? raw : raw.controls ?? [];
  return arr.map((c: any) => ({ control_id: c.control_id, layer: c.layer ?? c.primary_layer ?? null }));
}

function allocationsFromSnapshot(snapshotJson: any): Map<string, AllocationSummary> {
  const map = new Map<string, AllocationSummary>();
  const allocations = snapshotJson?.allocations ?? [];
  for (const a of allocations) {
    if (!a?.control_id) continue;
    map.set(a.control_id, {
      control_id: a.control_id,
      status: a.status ?? "Customer",
      layer: a.rationale?.layer ?? a.layer ?? null,
    });
  }
  return map;
}

export async function GET() {
  const org = await requireOrg();
  const organizationId = org.organizationId;

  const boundaryRow = await db.query.accountBoundary.findFirst({
    where: eq(accountBoundary.organizationId, organizationId),
  });

  if (!boundaryRow) {
    return NextResponse.json({ error: "NO_BOUNDARY_CONFIGURED" }, { status: 400 });
  }

  const latestSnapshot = await db.query.boundarySnapshots.findFirst({
    where: eq(boundarySnapshots.organizationId, organizationId),
    orderBy: [desc(boundarySnapshots.createdAt)],
  });

  const allocationMap = latestSnapshot?.snapshotJson
    ? allocationsFromSnapshot(latestSnapshot.snapshotJson)
    : new Map<string, AllocationSummary>();

  const runs = await db
    .select({
      id: evidenceRuns.id,
      source: evidenceRuns.source,
      runFingerprint: evidenceRuns.runFingerprint,
      createdAt: evidenceRuns.createdAt,
    })
    .from(evidenceRuns)
    .where(eq(evidenceRuns.organizationId, organizationId))
    .orderBy(desc(evidenceRuns.createdAt));

  const latestRunBySource = new Map<string, { id: string; runFingerprint: string; createdAt: string }>();
  for (const r of runs) {
    if (!latestRunBySource.has(r.source)) {
      latestRunBySource.set(r.source, {
        id: r.id,
        runFingerprint: r.runFingerprint,
        createdAt: (r.createdAt as any)?.toISOString?.() ?? String(r.createdAt),
      });
    }
  }

  const runIds = [...latestRunBySource.values()].map((v) => v.id);

  const evidenceMap = new Map<string, EvidenceFindingSummary>();
  if (runIds.length) {
    const findings = await db
      .select({
        controlId: evidenceFindings.controlId,
        status: evidenceFindings.status,
        layer: evidenceFindings.layer,
        createdAt: evidenceFindings.createdAt,
      })
      .from(evidenceFindings)
      .where(inArray(evidenceFindings.runId, runIds))
      .orderBy(desc(evidenceFindings.createdAt));

    const seen = new Set<string>();
    for (const f of findings) {
      if (seen.has(f.controlId)) continue;
      seen.add(f.controlId);
      evidenceMap.set(f.controlId, {
        control_id: f.controlId,
        status: f.status === "pass" ? "pass" : f.status === "fail" ? "fail" : "unknown",
        layer: f.layer ?? null,
        created_at: (f.createdAt as any)?.toISOString?.() ?? String(f.createdAt),
      });
    }
  }

  const registry = loadControlsRegistry();
  const controlIds = registry.length
    ? registry.map((r) => r.control_id)
    : Array.from(new Set([...allocationMap.keys(), ...evidenceMap.keys()]));

  const rows = controlIds.map((controlId) => {
    const allocation = allocationMap.get(controlId) ?? null;
    const evidence = evidenceMap.get(controlId) ?? null;

    const registryLayer = registry.find((r) => r.control_id === controlId)?.layer ?? null;
    const allocationWithLayer =
      allocation ??
      (registryLayer
        ? { control_id: controlId, status: "Customer" as const, layer: registryLayer }
        : null);

    return synthesizeControlStatus({ controlId, allocation: allocationWithLayer, evidence });
  });

  return NextResponse.json({
    boundary_id: boundaryRow.boundaryId,
    allocation_hash_current: boundaryRow.allocationHashCurrent,
    latest_snapshot_created_at: latestSnapshot?.createdAt ?? null,
    latest_evidence_runs: Array.from(latestRunBySource.entries()).map(([source, v]) => ({
      source,
      run_id: v.id,
      run_fingerprint: v.runFingerprint,
      created_at: v.createdAt,
    })),
    rows,
  });
}