# Pack: Control Status + Snapshot Attestation + CONMON

Files:
- src/lib/evidence/controlStatus.ts
- src/lib/attestation/computeSnapshotSignature.ts
- src/app/api/boundary/control-status/route.ts
- drizzle/0019_snapshot_attestation_chain.sql (migration stub)
- docs/conmon-gap-analysis.md

Notes:
- The API route assumes your drizzle schema exports: accountBoundary, boundarySnapshots, evidenceRuns, evidenceFindings.
- Adjust imports if your schema module path differs (some repos split schema into multiple files).
- To actually persist snapshot signatures, call computeSnapshotSignature during snapshot creation and store:
  - snapshot_signature
  - evidence_run_fingerprints (array)