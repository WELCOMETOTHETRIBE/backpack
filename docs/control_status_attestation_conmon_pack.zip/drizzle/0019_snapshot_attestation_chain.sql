-- Migration stub: Snapshot attestation chain fields
-- Adjust table name and column names to match your schema (boundarySnapshots table).

ALTER TABLE "boundary_snapshot"
  ADD COLUMN IF NOT EXISTS "snapshot_signature" text;

ALTER TABLE "boundary_snapshot"
  ADD COLUMN IF NOT EXISTS "evidence_run_fingerprints" jsonb;

CREATE INDEX IF NOT EXISTS "boundary_snapshot_signature_idx" ON "boundary_snapshot" ("snapshot_signature");