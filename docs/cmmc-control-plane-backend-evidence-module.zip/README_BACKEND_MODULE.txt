Backend module drop-in (metadata-only)

This repo's README states the Control Plane stores only metadata (RunId, path, SHA-256) and does not ingest enclave artifacts.
This module follows that rule.

Included:
- drizzle/schema.evidence.ts : new drizzle tables for evidence metadata + per-run technical status
- src/data/control-library.v1.json : canonical control library (v1)
- src/data/portal-control-schema.v1.json : portal adjudication schema (v1)
- src/lib/compliance/schemas.ts : loaders
- src/app/api/evidence-runs/import/route.ts : POST metadata-only import
- src/app/api/evidence-runs/[runId]/technical-status/route.ts : GET technical status summary

Integration:
1) Copy these files into your repo, preserving paths.
2) Export tables from drizzle/schema.evidence.ts via your existing schema barrel, OR import directly where needed.
3) Run `npx drizzle-kit push` (or your migration workflow).
4) Call POST /api/evidence-runs/import with manifest + file list (no artifacts).
