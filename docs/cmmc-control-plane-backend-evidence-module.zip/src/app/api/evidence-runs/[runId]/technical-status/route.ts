import { NextResponse } from "next/server";
import { db } from "@/src/db"; // adjust if your db import path differs
import { evidenceRuns, evidenceControlTechnicalStatus } from "@/drizzle/schema.evidence";
import { eq } from "drizzle-orm";

/**
 * GET /api/evidence-runs/:runId/technical-status
 */
export async function GET(_req: Request, ctx: { params: { runId: string } }) {
  const runId = ctx.params.runId;

  const run = await db.query.evidenceRuns.findFirst({
    where: eq(evidenceRuns.runId, runId),
  });

  if (!run) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const rows = await db
    .select()
    .from(evidenceControlTechnicalStatus)
    .where(eq(evidenceControlTechnicalStatus.evidenceRunId, run.id));

  const summary = {
    total: rows.length,
    pass: rows.filter((r: any) => r.technicalOk).length,
    fail: rows.filter((r: any) => !r.technicalOk).length,
  };

  return NextResponse.json({ run_id: runId, summary, rows });
}
