# Azure Commercial IaaS Boundary Engine Data Pack

Contains:
- provider_profiles/microsoft_azure_commercial_iaas.v1.json
- catalog/azure_commercial_services_to_layers.v1.json

Drop these into:
src/boundary-engine/data/provider_profiles/
src/boundary-engine/data/catalog/

Then update the boundary-engine orchestrator to resolve profile+catalog based on boundaryInput.provider/environment/hosting_model.

This pack assumes:
- layers_ontology.v1.json ontology_id = wttt-boundary-layers-v1 and version = 1.0.0
- validators enforce ontology version locks