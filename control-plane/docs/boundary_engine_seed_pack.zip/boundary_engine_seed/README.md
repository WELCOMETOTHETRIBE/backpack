# Boundary Engine Seed Pack (Azure Government / IaaS)

This zip contains the core data files needed to compute control allocation (Inherited / Shared / Customer) from a user-defined system boundary.

## Files

- `provider_profiles/microsoft_azure_government_iaas.v1.json`
  Provider profile for Azure Government (IaaS). Defines always-inherited layers and never-inherited governance layers.

- `ontology/layers_ontology.v1.json`
  Canonical layer enum. All control registry `layer` fields MUST match one of these values (case-sensitive).

- `catalog/azure_gov_services_to_layers.v1.json`
  Normalized catalog mapping Azure Gov services to the layers they support.

- `gates/gate_checklists.v1.json`
  Gate checklist schema for each optional service. A service contributes layers only when its required gates evaluate to 'yes'.

- `examples/example_boundary_input.v1.json`
  Example boundary input + gate answers payload.

## How to use

Your engine should:
1. Validate that all layer strings referenced are present in the ontology.
2. Load provider profile + service catalog + gate schema.
3. Evaluate gates for enabled services.
4. For each control in your `controls_registry.json`:
   - If control.layer in provider.never_inherited_layers -> Customer
   - Else if control.layer in provider.always_inherited_layers -> Inherited
   - Else if control.layer is covered by any enabled service with satisfied gates -> Shared
   - Else -> use control.default_allocation[hosting_model]

## Notes

This seed pack does NOT include the full 110-control registry to avoid duplicating your canonical control source of truth.
Integrate it with your existing `controls.json` (NIST 800-171 Rev2 110 controls) and ensure each control has a valid `layer`.