export interface Control {
  id: string;
  title: string;
  summary: string;
  requirement: string;
  nistGuidance: string;
  onboardingTips: string;
  objectives: Array<{ id: string; text: string }>;
  scoring: { sprs: number; weight: string };
  classification: { technical: boolean; governance: boolean; hybrid: boolean };
  metadata: { domain: string; family: string; nistId: string; level: string };
  complianceMeta: {
    satisfactionType: string;
    requiredArtifacts: Array<{ name: string; handling: string }>;
  };
  assessorInterrogation: {
    assessorQuestions: string;
    examineCriteria: string;
    testProcedures: string;
  };
}

export interface ComplianceState {
  selectedFamily: string | null;
  selectedControlTypes: Set<'technical' | 'governance' | 'hybrid'>;
  searchQuery: string;
  completedObjectives: Map<string, Set<string>>;
  viewMode: 'card' | 'list' | 'grid';
}

export interface ComplianceMetrics {
  totalControls: number;
  completedControls: number;
  complianceScore: number;
  domainMetrics: Record<
    string,
    {
      total: number;
      completed: number;
      sprs5: number;
      sprs3: number;
      sprs1: number;
    }
  >;
  priorityDistribution: { sprs5: number; sprs3: number; sprs1: number };
}

export interface DomainInfo {
  code: string;
  name: string;
  description: string;
}

export const DOMAINS: Record<string, DomainInfo> = {
  AC: { code: 'AC', name: 'Access Control', description: 'Manage user access and permissions' },
  AT: { code: 'AT', name: 'Awareness and Training', description: 'Security training programs' },
  AU: { code: 'AU', name: 'Audit and Accountability', description: 'Logging and monitoring' },
  CA: { code: 'CA', name: 'Security Assessment', description: 'Risk and compliance assessments' },
  CM: { code: 'CM', name: 'Configuration Management', description: 'System configuration control' },
  IA: { code: 'IA', name: 'Identification and Authentication', description: 'User identity verification' },
  IR: { code: 'IR', name: 'Incident Response', description: 'Security incident handling' },
  MA: { code: 'MA', name: 'Maintenance', description: 'System maintenance and support' },
  MP: { code: 'MP', name: 'Media Protection', description: 'Data storage and disposal' },
  PE: { code: 'PE', name: 'Physical Protection', description: 'Physical security controls' },
  PS: { code: 'PS', name: 'Personnel Security', description: 'Employee security policies' },
  RA: { code: 'RA', name: 'Risk Assessment', description: 'Risk identification and analysis' },
  SC: { code: 'SC', name: 'System and Communications Protection', description: 'Network security' },
  SI: { code: 'SI', name: 'System and Information Integrity', description: 'System security and updates' },
};
