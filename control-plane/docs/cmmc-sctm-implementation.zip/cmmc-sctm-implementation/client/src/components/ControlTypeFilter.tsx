import React from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

interface ControlTypeFilterProps {
  selectedTypes: Set<'technical' | 'governance' | 'hybrid'>;
  onToggleType: (type: 'technical' | 'governance' | 'hybrid') => void;
  typeCounts: { technical: number; governance: number; hybrid: number };
}

export function ControlTypeFilter({
  selectedTypes,
  onToggleType,
  typeCounts,
}: ControlTypeFilterProps) {
  const types: Array<{ id: 'technical' | 'governance' | 'hybrid'; label: string; color: string }> = [
    { id: 'technical', label: 'Technical', color: 'bg-purple-100 text-purple-700' },
    { id: 'governance', label: 'Governance', color: 'bg-green-100 text-green-700' },
    { id: 'hybrid', label: 'Hybrid', color: 'bg-indigo-100 text-indigo-700' },
  ];

  return (
    <div className="flex gap-4 mb-4">
      {types.map(({ id, label, color }) => (
        <div key={id} className="flex items-center gap-2">
          <Checkbox
            id={`type-${id}`}
            checked={selectedTypes.has(id)}
            onCheckedChange={() => onToggleType(id)}
          />
          <Label htmlFor={`type-${id}`} className="cursor-pointer">
            {label}
            <span className="ml-1 text-xs opacity-75">({typeCounts[id]})</span>
          </Label>
        </div>
      ))}
    </div>
  );
}
