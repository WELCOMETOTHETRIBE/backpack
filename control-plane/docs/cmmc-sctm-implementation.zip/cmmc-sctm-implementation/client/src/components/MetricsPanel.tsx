import React from 'react';
import { BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis } from 'recharts';
import type { ComplianceMetrics } from '@/types/control';

interface MetricsPanelProps {
  metrics: ComplianceMetrics;
}

export function MetricsPanel({ metrics }: MetricsPanelProps) {
  const priorityData = [
    { name: 'High (5 pts)', value: metrics.priorityDistribution.sprs5, fill: '#dc2626' },
    { name: 'Medium (3 pts)', value: metrics.priorityDistribution.sprs3, fill: '#f59e0b' },
    { name: 'Basic (1 pt)', value: metrics.priorityDistribution.sprs1, fill: '#3b82f6' },
  ];

  return (
    <div className="glass rounded-xl p-6 shadow-apple-lg border border-slate-100 space-y-6">
      {/* Overall Score */}
      <div>
        <h3 className="text-sm font-semibold text-slate-900 mb-2">Overall Compliance</h3>
        <div className="flex items-center gap-4">
          <div className="relative w-24 h-24">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="48"
                cy="48"
                r="40"
                fill="none"
                stroke="#e5e7eb"
                strokeWidth="4"
              />
              <circle
                cx="48"
                cy="48"
                r="40"
                fill="none"
                stroke="#3b82f6"
                strokeWidth="4"
                strokeDasharray={`${(metrics.complianceScore / 100) * 251.2} 251.2`}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-2xl font-bold text-slate-900">{metrics.complianceScore}%</span>
            </div>
          </div>
          <div>
            <p className="text-sm text-slate-600">
              {metrics.completedControls} of {metrics.totalControls} controls completed
            </p>
          </div>
        </div>
      </div>

      {/* Priority Distribution */}
      <div>
        <h3 className="text-sm font-semibold text-slate-900 mb-3">Priority Distribution</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={priorityData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Bar dataKey="value" fill="#3b82f6" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Domain Status */}
      <div>
        <h3 className="text-sm font-semibold text-slate-900 mb-3">Domain Status</h3>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {Object.entries(metrics.domainMetrics).map(([domain, stats]) => (
            <div key={domain} className="flex items-center gap-2 text-xs">
              <span className="font-semibold w-8">{domain}</span>
              <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-blue-500 to-blue-600"
                  style={{ width: `${(stats.completed / stats.total) * 100}%` }}
                />
              </div>
              <span className="text-slate-600 w-12 text-right">
                {stats.completed}/{stats.total}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
