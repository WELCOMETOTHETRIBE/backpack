import React from 'react';
import { DOMAINS } from '@/types/control';
import { Button } from '@/components/ui/button';

interface ControlFamilyTabsProps {
  selectedFamily: string | null;
  onSelectFamily: (family: string | null) => void;
  familyCounts: Record<string, number>;
}

export function ControlFamilyTabs({
  selectedFamily,
  onSelectFamily,
  familyCounts,
}: ControlFamilyTabsProps) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
      <Button
        onClick={() => onSelectFamily(null)}
        variant={selectedFamily === null ? 'default' : 'outline'}
        className="whitespace-nowrap"
      >
        All Domains
      </Button>
      {Object.entries(DOMAINS).map(([code, domain]) => (
        <Button
          key={code}
          onClick={() => onSelectFamily(code)}
          variant={selectedFamily === code ? 'default' : 'outline'}
          className="whitespace-nowrap"
        >
          {code}
          <span className="ml-2 text-xs opacity-75">({familyCounts[code] || 0})</span>
        </Button>
      ))}
    </div>
  );
}
