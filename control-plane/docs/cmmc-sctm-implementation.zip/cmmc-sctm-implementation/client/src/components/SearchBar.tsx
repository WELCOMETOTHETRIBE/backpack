import React, { useCallback, useState } from 'react';
import { Search, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function SearchBar({
  value,
  onChange,
  placeholder = 'Search controls by title, description, or objective...',
}: SearchBarProps) {
  const [localValue, setLocalValue] = useState(value);

  const handleClear = useCallback(() => {
    setLocalValue('');
    onChange('');
  }, [onChange]);

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const newValue = e.target.value;
      setLocalValue(newValue);
      onChange(newValue);
    },
    [onChange]
  );

  return (
    <div className="relative mb-4">
      <Search className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
      <Input
        type="text"
        placeholder={placeholder}
        value={localValue}
        onChange={handleChange}
        className="pl-10 pr-10"
      />
      {localValue && (
        <Button
          onClick={handleClear}
          variant="ghost"
          size="sm"
          className="absolute right-2 top-2"
        >
          <X className="w-4 h-4" />
        </Button>
      )}
    </div>
  );
}
