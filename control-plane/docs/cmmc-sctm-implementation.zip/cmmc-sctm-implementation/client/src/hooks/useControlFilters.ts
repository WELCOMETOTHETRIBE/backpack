import { useMemo } from 'react';
import type { Control, ComplianceState } from '@/types/control';

export function useControlFilters(
  controls: Control[],
  state: ComplianceState
) {
  const filteredControls = useMemo(() => {
    return controls.filter((control) => {
      // Filter by domain/family
      if (state.selectedFamily && control.metadata.domain !== state.selectedFamily) {
        return false;
      }

      // Filter by control type
      if (state.selectedControlTypes.size > 0) {
        const hasSelectedType =
          (state.selectedControlTypes.has('technical') && control.classification.technical) ||
          (state.selectedControlTypes.has('governance') && control.classification.governance) ||
          (state.selectedControlTypes.has('hybrid') && control.classification.hybrid);
        if (!hasSelectedType) return false;
      }

      // Filter by search query
      if (state.searchQuery.trim()) {
        const query = state.searchQuery.toLowerCase();
        const searchableText = [
          control.title,
          control.summary,
          control.requirement,
          control.metadata.family,
          control.metadata.nistId,
          ...control.objectives.map((obj) => obj.text),
        ]
          .join(' ')
          .toLowerCase();
        if (!searchableText.includes(query)) return false;
      }

      return true;
    });
  }, [controls, state.selectedFamily, state.selectedControlTypes, state.searchQuery]);

  return filteredControls;
}
