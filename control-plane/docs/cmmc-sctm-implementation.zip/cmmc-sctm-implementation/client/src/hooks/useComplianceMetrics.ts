import { useMemo } from 'react';
import type { Control, ComplianceMetrics, ComplianceState } from '@/types/control';

export function useComplianceMetrics(
  controls: Control[],
  state: ComplianceState
): ComplianceMetrics {
  return useMemo(() => {
    const domainMetrics: Record<
      string,
      {
        total: number;
        completed: number;
        sprs5: number;
        sprs3: number;
        sprs1: number;
      }
    > = {};

    let totalControls = 0;
    let totalCompleted = 0;
    let totalSPRS = 0;
    let completedSPRS = 0;
    const priorityDistribution = { sprs5: 0, sprs3: 0, sprs1: 0 };

    controls.forEach((control) => {
      const domain = control.metadata.domain;
      if (!domainMetrics[domain]) {
        domainMetrics[domain] = { total: 0, completed: 0, sprs5: 0, sprs3: 0, sprs1: 0 };
      }

      domainMetrics[domain].total++;
      totalControls++;

      // Track SPRS distribution
      if (control.scoring.sprs === 5) {
        domainMetrics[domain].sprs5++;
        priorityDistribution.sprs5++;
      } else if (control.scoring.sprs === 3) {
        domainMetrics[domain].sprs3++;
        priorityDistribution.sprs3++;
      } else {
        domainMetrics[domain].sprs1++;
        priorityDistribution.sprs1++;
      }

      totalSPRS += control.scoring.sprs;

      // Check if all objectives are completed
      const completedObjs = state.completedObjectives.get(control.id) || new Set();
      if (completedObjs.size === control.objectives.length && control.objectives.length > 0) {
        domainMetrics[domain].completed++;
        totalCompleted++;
        completedSPRS += control.scoring.sprs;
      }
    });

    const complianceScore = totalSPRS > 0 ? Math.round((completedSPRS / totalSPRS) * 100) : 0;

    return {
      totalControls,
      completedControls: totalCompleted,
      complianceScore,
      domainMetrics,
      priorityDistribution,
    };
  }, [controls, state.completedObjectives]);
}
