import React, { useState, useCallback, useMemo } from 'react';
import ControlCard from '@/components/ControlCard';
import { ControlFamilyTabs } from '@/components/ControlFamilyTabs';
import { ControlTypeFilter } from '@/components/ControlTypeFilter';
import { SearchBar } from '@/components/SearchBar';
import { MetricsPanel } from '@/components/MetricsPanel';
import { useControlFilters } from '@/hooks/useControlFilters';
import { useComplianceMetrics } from '@/hooks/useComplianceMetrics';
import type { Control, ComplianceState } from '@/types/control';
import cmmc110Rules from '@/data/cmmc-rules.json';

export default function ControlDashboard() {
  const [state, setState] = useState<ComplianceState>({
    selectedFamily: null,
    selectedControlTypes: new Set(),
    searchQuery: '',
    completedObjectives: new Map(),
    viewMode: 'card',
  });

  const controls = cmmc110Rules as Control[];
  const filteredControls = useControlFilters(controls, state);
  const metrics = useComplianceMetrics(controls, state);

  // Calculate counts by family
  const familyCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    controls.forEach((control) => {
      counts[control.metadata.domain] = (counts[control.metadata.domain] || 0) + 1;
    });
    return counts;
  }, [controls]);

  // Calculate counts by type
  const typeCounts = useMemo(() => {
    return {
      technical: controls.filter((c) => c.classification.technical).length,
      governance: controls.filter((c) => c.classification.governance).length,
      hybrid: controls.filter((c) => c.classification.hybrid).length,
    };
  }, [controls]);

  const handleSelectFamily = useCallback((family: string | null) => {
    setState((prev) => ({ ...prev, selectedFamily: family }));
  }, []);

  const handleToggleControlType = useCallback((type: 'technical' | 'governance' | 'hybrid') => {
    setState((prev) => {
      const newTypes = new Set(prev.selectedControlTypes);
      if (newTypes.has(type)) {
        newTypes.delete(type);
      } else {
        newTypes.add(type);
      }
      return { ...prev, selectedControlTypes: newTypes };
    });
  }, []);

  const handleSearchChange = useCallback((query: string) => {
    setState((prev) => ({ ...prev, searchQuery: query }));
  }, []);

  const handleToggleObjective = useCallback((controlId: string, objectiveId: string) => {
    setState((prev) => {
      const newCompleted = new Map(prev.completedObjectives);
      const controlObjs = newCompleted.get(controlId) || new Set();
      const newControlObjs = new Set(controlObjs);

      if (newControlObjs.has(objectiveId)) {
        newControlObjs.delete(objectiveId);
      } else {
        newControlObjs.add(objectiveId);
      }

      if (newControlObjs.size === 0) {
        newCompleted.delete(controlId);
      } else {
        newCompleted.set(controlId, newControlObjs);
      }

      return { ...prev, completedObjectives: newCompleted };
    });
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      {/* Header */}
      <div className="glass sticky top-0 z-50 shadow-apple-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">CMMC Level 2 Controls</h1>
          <p className="text-slate-600">Manage and track all 110 NIST SP 800-171 Rev 2 controls</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar - Filters */}
          <div className="lg:col-span-1">
            <div className="glass rounded-xl p-6 shadow-apple-md border border-slate-100 sticky top-24">
              <h2 className="text-lg font-semibold text-slate-900 mb-4">Filters</h2>

              <div className="space-y-6">
                {/* Search */}
                <div>
                  <label className="text-sm font-semibold text-slate-900 mb-2 block">Search</label>
                  <SearchBar value={state.searchQuery} onChange={handleSearchChange} />
                </div>

                {/* Control Type Filter */}
                <div>
                  <label className="text-sm font-semibold text-slate-900 mb-3 block">
                    Control Type
                  </label>
                  <ControlTypeFilter
                    selectedTypes={state.selectedControlTypes}
                    onToggleType={handleToggleControlType}
                    typeCounts={typeCounts}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Center - Controls */}
          <div className="lg:col-span-2 space-y-4">
            {/* Family Tabs */}
            <ControlFamilyTabs
              selectedFamily={state.selectedFamily}
              onSelectFamily={handleSelectFamily}
              familyCounts={familyCounts}
            />

            {/* Controls List */}
            {filteredControls.length > 0 ? (
              <div className="space-y-4">
                {filteredControls.map((control) => (
                  <ControlCard
                    key={control.id}
                    {...control}
                    onToggleObjective={(objId) => handleToggleObjective(control.id, objId)}
                  />
                ))}
              </div>
            ) : (
              <div className="glass rounded-xl p-12 text-center shadow-apple-md border border-slate-100">
                <p className="text-slate-600">No controls match your filters.</p>
              </div>
            )}
          </div>

          {/* Right Sidebar - Metrics */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <MetricsPanel metrics={metrics} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
