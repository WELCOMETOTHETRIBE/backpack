# CMMC SCTM Installation Guide

## Quick Start

This package contains all the files you need to implement the CMMC Control Card dashboard in your React project.

## Files Included

```
client/src/
├── types/
│   └── control.ts              # TypeScript interfaces and types
├── hooks/
│   ├── useControlFilters.ts    # Filter logic hook
│   └── useComplianceMetrics.ts # Metrics calculation hook
├── components/
│   ├── ControlFamilyTabs.tsx   # Domain selector tabs
│   ├── ControlTypeFilter.tsx   # Control type filter
│   ├── SearchBar.tsx           # Full-text search
│   └── MetricsPanel.tsx        # Compliance metrics dashboard
├── pages/
│   └── ControlDashboard.tsx    # Main dashboard page
└── data/
    └── cmmc-rules.json         # 110 CMMC controls dataset

docs/
├── CURSOR_PROMPT.md            # Cursor AI prompt
└── INSTALLATION.md             # This file
```

## Installation Steps

### 1. Copy Files to Your Project

Copy the entire `client/src/` directory structure into your project:

```bash
# From the extracted zip
cp -r client/src/types/* your-project/client/src/types/
cp -r client/src/hooks/* your-project/client/src/hooks/
cp -r client/src/components/* your-project/client/src/components/
cp -r client/src/pages/ControlDashboard.tsx your-project/client/src/pages/
cp -r client/src/data/* your-project/client/src/data/
```

### 2. Install Dependencies

```bash
cd your-project
pnpm add recharts
```

### 3. Update Your App.tsx

Add the ControlDashboard route:

```typescript
import { Route, Switch } from "wouter";
import ControlDashboard from "./pages/ControlDashboard";
import Home from "./pages/Home";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={ControlDashboard} />
      <Route path={"/home"} component={Home} />
      {/* ... other routes */}
    </Switch>
  );
}
```

### 4. Update ControlCard.tsx

Add the `onToggleObjective` prop to your existing ControlCard component:

```typescript
interface ControlCardProps {
  // ... existing props
  onToggleObjective?: (objectiveId: string) => void;
}

// In the component, update the objective checkbox:
<input
  type="checkbox"
  checked={completedObjectives.has(obj.id)}
  onChange={() => {
    toggleObjective(obj.id);
    onToggleObjective?.(obj.id);
  }}
/>
```

### 5. Verify CSS Utilities

Ensure your `client/src/index.css` includes the glassmorphism utilities:

```css
@layer components {
  .glass {
    @apply backdrop-blur-[12px] bg-white/70 border border-white/20;
  }
  
  .glass-dark {
    @apply backdrop-blur-[12px] bg-slate-950/40 border border-white/10;
  }
  
  .shadow-apple-sm {
    @apply shadow-[0_1px_3px_rgba(0,0,0,0.1),0_1px_2px_rgba(0,0,0,0.06)];
  }
  
  .shadow-apple-md {
    @apply shadow-[0_4px_6px_rgba(0,0,0,0.1),0_2px_4px_rgba(0,0,0,0.06)];
  }
  
  .shadow-apple-lg {
    @apply shadow-[0_10px_15px_rgba(0,0,0,0.1),0_4px_6px_rgba(0,0,0,0.05)];
  }
  
  .shadow-apple-xl {
    @apply shadow-[0_20px_25px_rgba(0,0,0,0.1),0_8px_12px_rgba(0,0,0,0.04)];
  }
  
  .transition-smooth {
    @apply transition-all duration-300 ease-out;
  }
}
```

### 6. Test the Installation

```bash
pnpm dev
# Navigate to http://localhost:3000
```

## Features

### Domain Filtering
- Click domain tabs to filter controls
- "All Domains" shows all 110 controls
- Counts update in real-time

### Control Type Filtering
- Multi-select checkboxes for Technical, Governance, Hybrid
- Shows count of controls per type
- Combines with domain filter

### Search Functionality
- Full-text search across titles, descriptions, objectives
- Case-insensitive matching
- Debounced for performance

### Objective Tracking
- Click checkboxes to mark objectives complete
- Progress bar updates in real-time
- Completion percentage shown in header

### Metrics Dashboard
- Overall compliance score (weighted by SPRS)
- Priority distribution bar chart
- Domain status with progress bars
- Real-time updates

## Customization

### Change Colors

Update `client/src/index.css`:

```css
:root {
  --primary: oklch(0.623 0.214 259.815); /* Change this */
  --accent: oklch(0.623 0.214 259.815);
}
```

### Adjust Layout

Modify grid columns in `ControlDashboard.tsx`:

```typescript
<div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
  {/* Adjust lg:col-span-* values */}
</div>
```

### Add More Metrics

Extend `MetricsPanel.tsx` with new metric cards.

## Persistence (Optional)

Add localStorage to save user progress:

```typescript
// In ControlDashboard.tsx
useEffect(() => {
  const saved = localStorage.getItem('cmmc-progress');
  if (saved) {
    setState((prev) => ({
      ...prev,
      completedObjectives: new Map(JSON.parse(saved)),
    }));
  }
}, []);

useEffect(() => {
  localStorage.setItem(
    'cmmc-progress',
    JSON.stringify(Array.from(state.completedObjectives.entries()))
  );
}, [state.completedObjectives]);
```

## Troubleshooting

### Controls not loading
- Check `cmmc-rules.json` exists in `client/src/data/`
- Verify JSON structure matches Control interface
- Check browser console for import errors

### Filters not working
- Verify `useControlFilters` hook is called with correct state
- Check filter logic in hook implementation
- Ensure state updates trigger re-renders

### Metrics not updating
- Verify `useComplianceMetrics` is called after state changes
- Check completedObjectives Map is being updated correctly
- Ensure SPRS scores are correct in JSON

### Performance issues
- Profile with React DevTools
- Check for unnecessary re-renders
- Implement React.memo on ControlCard
- Use useMemo for expensive calculations

## Support

For detailed implementation guidance, refer to:
- `docs/CURSOR_PROMPT.md` - Cursor AI prompt with full specifications
- Component files have inline comments explaining key logic
- Use React DevTools to debug state management

## Next Steps

1. Test the installation
2. Customize colors and layout to match your brand
3. Add localStorage persistence (optional)
4. Implement evidence upload feature
5. Add PDF export functionality
