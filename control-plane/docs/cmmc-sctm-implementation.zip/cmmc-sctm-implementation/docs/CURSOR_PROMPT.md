# CMMC SCTM Control Card Implementation - Cursor Prompt

## Project Context

You are implementing a **CMMC Level 2 Compliance Dashboard** with an interactive Control Card system. The application will display all 110 NIST SP 800-171 Rev 2 controls with real-time filtering, progress tracking, and compliance metrics.

## Design Philosophy

**Apple-Inspired Premium Interface:**
- Glassmorphism with backdrop blur effects
- Layered shadow system for depth (sm, md, lg, xl)
- Smooth transitions and micro-interactions
- Clean typography hierarchy using Geist font family
- Semantic color system with OKLCH color space
- Responsive design with mobile-first approach

## Core Features to Implement

### 1. **Control Family Header with Filtering**

Create a sophisticated header component that displays:
- **Control Family Selector**: Horizontal scrollable tabs showing all 14 NIST domains (AC, AT, AU, CA, CM, IA, IR, MA, MP, PE, PS, RA, SC, SI)
- **Control Type Filter**: Multi-select filter for Technical, Governance, and Hybrid controls
- **Real-Time Tallies**: Display counts for:
  - Total controls in selected family
  - Completed controls (checkboxes marked)
  - High-priority controls (SPRS 5)
  - Medium-priority controls (SPRS 3)
  - Basic controls (SPRS 1)
- **Search Bar**: Full-text search across control titles, descriptions, and objectives
- **View Mode Toggle**: Switch between Card View, List View, and Grid View

### 2. **Control Card Component**

Enhance the existing ControlCard component with:
- **Header Section**: Domain badge, control title, NIST ID, summary
- **Status Indicators**: SPRS score, satisfaction type, completion percentage
- **Collapsible Sections**:
  - Assessment Objectives (with checkbox tracking)
  - Required Artifacts (with UPLOAD/REFERENCE/N/A badges)
  - NIST Guidance and Implementation Tips
  - Assessor Interrogation (Interview, Examine, Test)
- **Quick Actions**: Mark as Complete, Add Notes, Link to Evidence

### 3. **Dashboard Metrics Panel**

Display compliance metrics:
- **Overall Compliance Score**: Percentage based on completed controls weighted by SPRS
- **Domain Breakdown**: Pie/donut chart showing completion by domain
- **Priority Distribution**: Bar chart showing SPRS 5, 3, 1 distribution
- **Completion Timeline**: Progress indicators for each domain
- **Risk Heatmap**: Color-coded grid showing which domains need attention

### 4. **Data Integration**

- Load the 110-rule JSON dataset (cmmc-rules.json)
- Implement local state management for:
  - Selected control family filter
  - Selected control type filters
  - Completed objectives per control
  - Search query
  - Current view mode
- Optional: Add localStorage persistence for user progress

### 5. **Responsive Layout**

- **Desktop**: 3-column layout (filters, main content, metrics)
- **Tablet**: 2-column layout with collapsible sidebar
- **Mobile**: Single column with sticky header and bottom sheet for filters

## Technical Requirements

### Stack
- **Framework**: React 19 with TypeScript
- **Styling**: Tailwind CSS 4 with custom glassmorphism utilities
- **Components**: shadcn/ui for base components
- **Icons**: lucide-react for all iconography
- **State Management**: React hooks (useState, useContext)
- **Data**: Static JSON import with optional API integration

### File Structure
```
client/src/
├── components/
│   ├── ControlCard.tsx (existing - enhance)
│   ├── ControlFamilyTabs.tsx (new - domain selector)
│   ├── ControlTypeFilter.tsx (new - technical/governance/hybrid)
│   ├── MetricsPanel.tsx (new - compliance dashboard)
│   ├── SearchBar.tsx (new - full-text search)
│   └── ControlList.tsx (optional - list/grid view)
├── data/
│   └── cmmc-rules.json (import the 110-rule dataset)
├── hooks/
│   ├── useControlFilters.ts (filter logic)
│   └── useComplianceMetrics.ts (metrics calculation)
├── pages/
│   └── ControlDashboard.tsx (main page)
└── types/
    └── control.ts (TypeScript interfaces)
```

### Key Interfaces

```typescript
interface Control {
  id: string;
  title: string;
  summary: string;
  requirement: string;
  nistGuidance: string;
  onboardingTips: string;
  objectives: Array<{ id: string; text: string }>;
  scoring: { sprs: number; weight: string };
  classification: { technical: boolean; governance: boolean; hybrid: boolean };
  metadata: { domain: string; family: string; nistId: string; level: string };
  complianceMeta: {
    satisfactionType: string;
    requiredArtifacts: Array<{ name: string; handling: string }>;
  };
  assessorInterrogation: {
    assessorQuestions: string;
    examineCriteria: string;
    testProcedures: string;
  };
}

interface ComplianceState {
  selectedFamily: string | null;
  selectedControlTypes: Set<'technical' | 'governance' | 'hybrid'>;
  searchQuery: string;
  completedObjectives: Map<string, Set<string>>;
  viewMode: 'card' | 'list' | 'grid';
}

interface ComplianceMetrics {
  totalControls: number;
  completedControls: number;
  complianceScore: number;
  domainMetrics: Record<string, { total: number; completed: number; sprs5: number; sprs3: number; sprs1: number }>;
  priorityDistribution: { sprs5: number; sprs3: number; sprs1: number };
}
```

## Color Palette (OKLCH Format)

- **Primary**: `oklch(0.623 0.214 259.815)` - Professional Blue
- **Success**: `oklch(0.577 0.245 142.495)` - Emerald Green
- **Warning**: `oklch(0.704 0.191 22.216)` - Amber Orange
- **Danger**: `oklch(0.577 0.245 27.325)` - Red
- **Neutral**: `oklch(0.235 0.015 65)` - Dark Slate
- **Background**: `oklch(0.98 0.001 286.375)` - Off-White

## Implementation Steps

1. **Phase 1**: Create TypeScript interfaces and data loader
2. **Phase 2**: Build filter components (ControlFamilyTabs, ControlTypeFilter, SearchBar)
3. **Phase 3**: Implement metrics calculation hooks
4. **Phase 4**: Build MetricsPanel with charts
5. **Phase 5**: Create ControlList and view mode switcher
6. **Phase 6**: Integrate all components into ControlDashboard page
7. **Phase 7**: Add localStorage persistence
8. **Phase 8**: Optimize performance with useMemo and React.memo

## Design Specifications

### Header Component
- **Height**: 120px (desktop), 180px (mobile)
- **Background**: Glassmorphic with gradient overlay
- **Layout**: Flex row with tabs on left, filters on right, metrics in center
- **Spacing**: 16px padding, 8px gaps between elements

### Control Card
- **Width**: 100% (responsive)
- **Max-width**: 1024px on desktop
- **Padding**: 24px
- **Border-radius**: 16px
- **Shadow**: shadow-apple-lg
- **Animations**: Smooth expand/collapse (300ms ease-out)

### Metrics Panel
- **Width**: 320px (desktop), full-width (mobile)
- **Position**: Sticky right sidebar (desktop), bottom sheet (mobile)
- **Content**: 4-6 metric cards with mini charts

## Performance Considerations

- Use `useMemo` for filtered control lists (re-compute only when filters change)
- Use `React.memo` for ControlCard to prevent unnecessary re-renders
- Implement virtual scrolling for large lists (100+ items)
- Lazy load chart components (recharts)
- Debounce search input (300ms)

## Accessibility Requirements

- ARIA labels for all interactive elements
- Keyboard navigation support (Tab, Enter, Arrow keys)
- Color contrast ratio ≥ 4.5:1 for text
- Focus indicators visible on all focusable elements
- Screen reader friendly filter descriptions

## Testing Checklist

- [ ] All 110 controls load correctly
- [ ] Filters work independently and in combination
- [ ] Search finds controls by title, description, objectives
- [ ] Completion tracking persists across page refresh (localStorage)
- [ ] Metrics update in real-time as controls are marked complete
- [ ] Responsive layout works on mobile, tablet, desktop
- [ ] Animations are smooth (60fps)
- [ ] Accessibility: keyboard navigation works
- [ ] Accessibility: screen reader announces filter changes

## Future Enhancements

1. **Evidence Upload**: Integrate file upload for artifacts
2. **Audit Trail**: Track when controls were marked complete and by whom
3. **Collaboration**: Real-time sync for team compliance tracking
4. **Export**: Generate PDF compliance reports
5. **Notifications**: Alert when high-priority controls are due
6. **Integration**: Connect to Azure/AWS for automated evidence collection
7. **AI Assistant**: ChatGPT-powered compliance advisor for each control

## Notes

- The existing ControlCard component should be enhanced, not replaced
- Maintain the glassmorphism aesthetic throughout
- Use the Geist font family for consistency
- Keep the component hierarchy shallow for performance
- Document all custom hooks for maintainability
